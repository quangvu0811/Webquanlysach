<section class="footer">

    <div class="box-container">
        <div class="box">
            <h3>links </h3>
            <a href="home.php">home</a>
            <a href="about.php">about</a>
            <a href="shop.php">shop</a>
            <a href="contact.php">contact</a>
          
        </div>

        <div class="box">
            <h3>links Phu</h3>
            <a href="login.php">Đăng Nhập</a>
            <a href="register.php">Đăng ký</a>
            <a href="cart.php">shop</a>         
            <a href="orders.php">orders</a>
        </div>

        <div class="box">
            <h3>Dia-Chi Thong-Tin</h3>
            <p> <i class="fas fa-phone"></i>19001000</p>
            <p> <i class="fas fa-phone"></i>19001111</p>           
            <p> <i class="fas fa-envelope"></i>quangtruong@gamil.com</p>
            <p> <i class="fas fa-map-marker-alt"></i>Thanh hoa - Viet Nam</p>
        </div>
        <div class="box">

                <h3>folow us</h3>
                <a href="#">  <i class="fab fa-facebook-f"></i> facebook</a>
                <a href="#">  <i class="fab fa-twitter"></i>twitter</a>
                <a href="#">  <i class="fab fa-instagram"></i>instagram</a>
                <a href="#">  <i class="fab fa-tiktok"></i>tiktok</a>

        </div>



    </div >

    <p class="credit"> Coder : <span> web-QuangTruong</span> @<?php echo date('Y') ?></p>

</section>